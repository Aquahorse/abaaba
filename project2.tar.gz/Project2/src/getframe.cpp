#include<iostream>
#include<string>
#include<stdio.h>
#include<sstream>
extern"C"{
    #include<libavcodec/avcodec.h>
    #include <libavutil/pixdesc.h>
    #include<libavformat/avformat.h>
    #include<libavutil/avutil.h>
    #include<libavutil/frame.h>
    #include<libswscale/swscale.h>
    
}
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"
#define STB_IMAGE_RESIZE_IMPLEMENTATION
#include "stb_image_resize.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define STBIR_ASSERT()


using namespace std;
const int NUMHEIGHT = 98;
const int NUMWIDTH = 45;
const int NUMCHANNEL = 4;
const int NUMBLANK = 10;

static AVFrame *pAVFrame;
static AVRational timebase;
static int frame_cnt = 0;
static int chosen_frame_num = 1;
int resize_and_add_time(string filename, int x_pixel, int y_pixel, int timestamp);

int get_sample_frame(const char *filename, int frame_num, AVFrame *frame);
static int open_codec_context(int *stream_idx, // comment to control clang-format line break, do not remove
                              AVCodecContext **dec_ctx, AVFormatContext *fmt_ctx, enum AVMediaType type);
static int decode_video(AVCodecContext *dec_ctx, AVPacket *pkt, AVFrame *last_frm);
static int print_frame(AVFrame *frame);

bool save_as_png(AVFrame* frame, const char* filename){
    int ret = stbi_write_png(filename, frame->width, frame->height, 3, frame->data[0], frame->linesize[0]);
    if(ret == 0){
        cout << "Failed to save frame as png" << endl;
        return false;
    }
    return true;
}

static int print_frame(AVFrame *frame)
{
	// Examine and process frame in the decoding loop here
	return 0;
	printf("Video frame coded_n: %d\n", frame->coded_picture_number);
	printf("\ttime: %f\n", av_q2d(timebase) * (double)frame->best_effort_timestamp);
    //convert frame->format to AVPixelformat
    AVPixelFormat pix_fmt = (AVPixelFormat)frame->format;
	printf("\twidth: %d, height: %d, format: %s\n", //
	       frame->width, frame->height, av_get_pix_fmt_name(pix_fmt));
}
string av_err22str(int ret){
    char errbuf[AV_ERROR_MAX_STRING_SIZE];
    av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
    return string(errbuf);
}
static int decode_video(AVCodecContext *dec_ctx, AVPacket *pkt, AVFrame *last_frm)
{
	int ret;

	ret = avcodec_send_packet(dec_ctx, pkt);
	if (ret < 0) {
		fprintf(stderr, "send_packet: %s\n", av_err22str(ret));
		return ret;
	}

	while (ret >= 0) {
		ret = avcodec_receive_frame(dec_ctx, pAVFrame);
		if (ret < 0) {
			if (ret == AVERROR_EOF || ret == AVERROR(EAGAIN)) return 0;

			fprintf(stderr, "receive_frame: %s\n", av_err22str(ret));
			return ret;
		}

		print_frame(pAVFrame);

		frame_cnt++;
		if (frame_cnt >= chosen_frame_num) {
			// Decoded past chosen number of frames, copy and return
			av_frame_ref(last_frm, pAVFrame);
			frame_cnt = 0;
			return 1;
		}

		av_frame_unref(pAVFrame);
	}

	return 0;
}

static int open_codec_context(int *stream_idx, //
                              AVCodecContext **dec_ctx, AVFormatContext *fmt_ctx, enum AVMediaType type)
{
	int ret, stream_index;
	AVStream *st;
	AVCodec *dec = NULL;
	AVDictionary *opts = NULL;

	if ((ret = av_find_best_stream(fmt_ctx, type, -1, -1, NULL, 0)) < 0) {
		fprintf(stderr, "Cannot find %s stream!\n", av_get_media_type_string(type));
	}

	stream_index = ret;
	st = fmt_ctx->streams[stream_index];

	dec = avcodec_find_decoder(st->codecpar->codec_id);
	if (!dec) {
		fprintf(stderr, "Failed to find a codec\n");
		return AVERROR(EINVAL);
	}

	*dec_ctx = avcodec_alloc_context3(dec);
	if (!*dec_ctx) {
		fprintf(stderr, "Failed to allocate AVCodecContext\n");
		return AVERROR(ENOMEM);
	}

	if ((ret = avcodec_parameters_to_context(*dec_ctx, st->codecpar)) < 0) {
		fprintf(stderr, "Failed to set decoder parameter: %s\n", av_err22str(ret));
		return ret;
	}

	if ((ret = avcodec_open2(*dec_ctx, dec, &opts)) < 0) {
		fprintf(stderr, "Failed to open codec: %s\n", av_err22str(ret));
		return ret;
	}

	*stream_idx = stream_index;
	return 0;
}


int get_sample_frame(const char *filename, int frame_num, AVFrame *frame)
{
	int ret, video_stream_idx,time_cnt = 0;
	int64_t tot_ts, start_ts; 
	AVCodecContext *dec_ctx = NULL;

	AVStream *stream = NULL;
	AVPacket *pkt = NULL;

	chosen_frame_num = frame_num;

	// Open Sample File
	AVFormatContext *fmt_ctx = avformat_alloc_context();
	if (fmt_ctx == NULL) {
		ret = AVERROR(ENOMEM);
		fprintf(stderr, "alloc_context: ENOMEM\n");
		goto end;
	}
	
	ret = avformat_open_input(&fmt_ctx, filename, NULL, NULL);
	tot_ts = fmt_ctx->duration;
	cout << "total_ts: " << tot_ts << endl;
	if (ret < 0) {
		fprintf(stderr, "open_input: %s\n", av_err22str(ret));
		goto end;
	}

	if ((ret = avformat_find_stream_info(fmt_ctx, NULL)) < 0) {
		fprintf(stderr, "find_stream_info: %s\n", av_err22str(ret));
		goto end;
	}

	if (open_codec_context(&video_stream_idx, &dec_ctx, fmt_ctx, AVMEDIA_TYPE_VIDEO) < 0) {
		fprintf(stderr, "open_codec_context: %s\n", av_err22str(ret));
		goto end;
	}
	stream = fmt_ctx->streams[video_stream_idx];
	//av_dump_format(fmt_ctx, 0, "yuv444.mkv", 0);
	pAVFrame = av_frame_alloc();
	if (!pAVFrame) {
		fprintf(stderr, "alloc_frame: ENOMEM\n");
		goto end;
	}

	pkt = av_packet_alloc();
	if (!pkt) {
		fprintf(stderr, "alloc_packet: ENOMEM\n");
		goto end;
	}
	for (int i=0;i<6;i++) {
		//get the time base
		double timebase = av_q2d(fmt_ctx->streams[video_stream_idx]->time_base) * AV_TIME_BASE;
		int64_t time = (int64_t)(((tot_ts/timebase)*i)/5);
		cout << "time: " << time << endl;
		//seek the frame to the timestamp
		ret = av_seek_frame(fmt_ctx, video_stream_idx, time, AVSEEK_FLAG_BACKWARD);
		if (ret < 0) {
			fprintf(stderr, "seek_frame: %s\n", av_err22str(ret));
			goto end;
		}
		avcodec_flush_buffers(dec_ctx);
		//read the frame
		//ret = av_read_frame(fmt_ctx, pkt);
		time_cnt=0;
		while (av_read_frame(fmt_ctx, pkt) >= 0 && time_cnt<=10) {
			cout << "read_frame: " << pkt->pts << endl;
			time_cnt ++;
			if (pkt->stream_index == video_stream_idx) {
				ret = avcodec_send_packet(dec_ctx, pkt);
				if (ret < 0) {
					cout << i << " failed" << endl;
					av_packet_unref(pkt);
					fprintf(stderr, "send_packet: %s\n", av_err22str(ret));
					goto end;
				}
				avcodec_receive_frame(dec_ctx, pAVFrame);
				// printf(
				// "Frame %c (%d) pts %d dts %d key_frame %d [coded_picture_number %d, display_picture_number %d]",
				// av_get_picture_type_char(pAVFrame->pict_type),
				// dec_ctx->frame_number,
				// pAVFrame->pts,
				// pAVFrame->pkt_dts,
				// pAVFrame->key_frame,
				// pAVFrame->coded_picture_number,
				// pAVFrame->display_picture_number
				// );
			}
		}
		if (pkt->stream_index == video_stream_idx) {
			ret = decode_video(dec_ctx, pkt, pAVFrame);
			if (ret < 0) {
				fprintf(stderr, "decode_video: %s\n", av_err22str(ret));
				goto end;
			}
            uint8_t* data;
            SwsContext *sws_ctx = sws_getContext(dec_ctx->width, dec_ctx->height, dec_ctx->pix_fmt, dec_ctx->width, dec_ctx->height, AV_PIX_FMT_RGBA, SWS_BILINEAR, NULL, NULL, NULL);
            data = new uint8_t[dec_ctx->width * dec_ctx->height * 4];
            int dst_line = 4*pAVFrame->width;
            sws_scale(sws_ctx, pAVFrame->data, pAVFrame->linesize, 0, pAVFrame->height, &data, &dst_line);
            //stbi_write_png("frame.png", dec_ctx->width, dec_ctx->height, 4, data, dec_ctx->width * 4);
			//get the string "frame%d.png" and replace the %d with the current frame number
			string file_name;
			//sprintf(file_name, "frame%d.png", i);
			//convert int i to string
			stringstream ss;
			ss << i;
			string str = ss.str();
			file_name = "frame" + str + ".png";
			stbi_write_png(file_name.c_str(), dec_ctx->width, dec_ctx->height, 4, data, dec_ctx->width * 4);
			resize_and_add_time(file_name, 720, 720, (int) time);
		}
        av_packet_unref(pkt);
		// if (ret != 0) 
		// 	goto end;
	}
end:
    av_frame_free(&frame);
	av_frame_free(&pAVFrame);
	av_packet_free(&pkt);
	avcodec_free_context(&dec_ctx);
	avformat_close_input(&fmt_ctx);
	avformat_free_context(fmt_ctx);
	//cout << "Here2" << endl;
	return ret;
}
string get_time_string(int timestamp){
	//this function gets the string "xx:xx:xx" according to the timestamp of the frame
	int hour, minute, second;
	hour = timestamp/3600;
	minute = (timestamp%3600)/60;
	second = timestamp%60;
	stringstream ss;
	if (hour<10){
		ss << '0' << hour << ':';
	}
	else{
		ss << hour << ':';
	}
	if (minute<10){
		ss << '0' << minute << ':';
	}
	else{
		ss << minute << ':';
	}
	if (second<10){
		ss << '0' << second;
	}
	else{
		ss << second;
	}
	return ss.str();
}

int resize_and_add_time(string filename, int x_pixel, int y_pixel,int timestamp){
	//this function is used to resize the image to the specified size
	//the input image is assumed to be in the format of png
	//the output image is in the format of png
	//the output image is saved in the same directory as the input image
	//the output image has the same name as the input image but with the suffix "_resized"

	//open the input image
	int width, height, channels;
	unsigned char* data = stbi_load(filename.c_str(), &width, &height, &channels, 0);
	cout << "width: " << width << " height: " << height << " channels: " << channels << endl;
	if (!data) {
		cout << "Error: " << stbi_failure_reason() << endl;
		return -1;
	}
	//create the output image
	x_pixel = min(x_pixel, width);
	y_pixel = min(y_pixel, height);
	const int INITIALBLANK = (x_pixel-8*NUMWIDTH-7*NUMBLANK)/2;
	unsigned char* data_resized;
	//resize the image into width x_pixel and height y_pixel
	//the output image is in the format of RGBA
	data_resized = new unsigned char[x_pixel * y_pixel * 4];
	//resize the image
	stbir_resize_uint8(data, width, height, 0, data_resized, x_pixel, y_pixel, 0, 4);
	unsigned char* data_final = new unsigned char[x_pixel*(y_pixel+NUMHEIGHT)*4];
	//move data_resized to data_final by copying memory
	memcpy(data_final, data_resized, x_pixel * y_pixel * 4);
	//get the uncovered part white
	for (int i = y_pixel; i < y_pixel+NUMHEIGHT; i++){
		for (int j = 0; j < x_pixel; j++){
			data_final[i*x_pixel*4+j*4] = 255;
			data_final[i*x_pixel*4+j*4+1] = 255;
			data_final[i*x_pixel*4+j*4+2] = 255;
			data_final[i*x_pixel*4+j*4+3] = 255;
		}
	}
	//add the time string to the image
	string time_string = get_time_string(timestamp);
	int time_string_length = time_string.length();
	for (int i=0; i<time_string_length; i++){
		//open "pixels/pixels/%d.txt" and get the pixel data
		stringstream ss;
		if (time_string[i] == ':'){
			ss << "pixels/pixels/colon.txt";
		}
		else{
			ss << "pixels/pixels/" << time_string[i] << ".txt";
		}
		string str = ss.str();
		freopen(str.c_str(), "r", stdin);
		string line;
		int r, g, b, a;
		int numheight, numwidth, numchannels;
		cin >> numheight >> numwidth >> numchannels;
		assert(numheight == NUMHEIGHT);
		assert(numwidth == NUMWIDTH);
		assert(numchannels == NUMCHANNEL);
		for (int j=0;j<NUMHEIGHT;j++){
			for (int k=0;k<NUMWIDTH;k++){
				int r, g, b, a;
				cin >> r >> g >> b >> a;
				int pos = ((j+y_pixel)*x_pixel+INITIALBLANK+i*(NUMWIDTH+NUMBLANK)+k)*4;
				data_final[pos] = r;
				data_final[pos+1] = g;
				data_final[pos+2] = b;
				data_final[pos+3] = a;
			}
		}
	}
	//save the image into "frame%d_resized.png"
	stringstream ss_frame;
	int i = filename[5] - '0';
	ss_frame << i;
	string str_frame = ss_frame.str();
	string file_name_resized = "frame" + str_frame + "_resized.png";
	stbi_write_png(file_name_resized.c_str(), x_pixel, y_pixel+NUMHEIGHT, 4, data_final, x_pixel * 4);
	//free the memory
	delete[] data_resized;
	delete[] data;
	delete[] data_final;
	
	return 0;
}
int combine_images(){
	//this function is to conbine the 6 images into one image
	//the images are assumed to be in the format of png
	//the output image is in the format of png
	//the output image is saved in the same directory as the input image
	//the input images are "frame%d_resized.png" where %d is the frame number ranged from 0 to 5
	//the output image is named "combined.png"
	//the output image doesn't need to be resized
	//the output image is in the format of RGBA
	//the first three images are in the first row
	//the second three images are in the second row

	//open the input images
	int width, height, channels;
	unsigned char* data[6];
	for (int i = 0; i < 6; i++) {
		string filename;
		stringstream ss;
		ss << i;
		string str = ss.str();
		filename = "frame" + str + "_resized.png";
		data[i] = stbi_load(filename.c_str(), &width, &height, &channels, 0);
		if (!data[i]) {
			cout << "Error: " << stbi_failure_reason() << endl;
			return -1;
		}
	}
	//create the output image
	unsigned char* data_combined;
	data_combined = new unsigned char[width * height * 24];
	//get the first three images
	for (int i = 0; i < 3; i++) {
		for (int j = 0; j < height; j++) {
			for (int k=0; k<width; k++) {
				data_combined[j*width*12 + i*width*4 + k*4] = data[i][j*width*4 + k*4];
				data_combined[j*width*12 + i*width*4 + k*4 + 1] = data[i][j*width*4 + k*4 + 1];
				data_combined[j*width*12 + i*width*4 + k*4 + 2] = data[i][j*width*4 + k*4 + 2];
				data_combined[j*width*12 + i*width*4 + k*4 + 3] = data[i][j*width*4 + k*4 + 3];
			}
		}
	}
	//get the second three images
	for (int i = 3; i < 6; i++) {
		for (int j = 0; j < height; j++) {
			for (int k=0; k<width; k++) {
				data_combined[(j+height)*width*12 + (i-3)*width*4 + k*4] = data[i][j*width*4 + k*4];
				data_combined[(j+height)*width*12 + (i-3)*width*4 + k*4 + 1] = data[i][j*width*4 + k*4 + 1];
				data_combined[(j+height)*width*12 + (i-3)*width*4 + k*4 + 2] = data[i][j*width*4 + k*4 + 2];
				data_combined[(j+height)*width*12 + (i-3)*width*4 + k*4 + 3] = data[i][j*width*4 + k*4 + 3];
			}
		}
	}
	cout << "width:" << width << endl;
	cout << "height:" << height << endl;
	//save the image
	stbi_write_png("combined.png", width*3, height*2, 4, data_combined, width * 12);
	cout << "Saved!" << endl;
	//free the memory
	for (int i = 0; i < 6; i++) {
		delete[] data[i];
	}
	delete[] data_combined;
	return 0;
}

int main(int argc,char** argv){
    //this code reads the file name from the input
    string filename=argv[1];
    //convert filename to a c string
    const char* filename_c=filename.c_str();
    get_sample_frame(filename_c,0,NULL);
	combine_images();
    return 0;
}
