height: 98
width: 45
channel: 4
